
BOSSBBY ULTRA PREMIUM

INSTALL:
npm install

RUN:
node bossbbytoursandtravel@gmail.com + bossbbyadmin

OPEN:
http://localhost:3000

EMAIL SETUP:
Edit server.js with your Gmail + App Password

ADMIN PASSWORD:
bossbbyadmin

FEATURES:
- Animated safari parallax hero
- Floating wildlife icons
- Live booking notifications
- AI chatbot assistant
- Payment ready (connect Stripe/Flutterwave)
- Branded premium UI
